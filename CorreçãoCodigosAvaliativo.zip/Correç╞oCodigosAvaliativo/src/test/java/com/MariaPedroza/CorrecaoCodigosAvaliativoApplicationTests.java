package com.MariaPedroza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorrecaoCodigosAvaliativoApplicationTests {

	@Test
	void contextLoads() {
	}

}
