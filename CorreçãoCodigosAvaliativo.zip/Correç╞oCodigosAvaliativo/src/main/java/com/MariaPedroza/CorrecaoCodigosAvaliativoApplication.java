package com.MariaPedroza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorrecaoCodigosAvaliativoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorrecaoCodigosAvaliativoApplication.class, args);
	}

}
