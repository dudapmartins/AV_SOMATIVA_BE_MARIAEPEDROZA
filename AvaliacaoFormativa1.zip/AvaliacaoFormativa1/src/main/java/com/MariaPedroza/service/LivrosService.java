package com.MariaPedroza.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MariaPedroza.entities.Livros;
import com.MariaPedroza.repository.LivrosRepository;

@Service
public class LivrosService {

	@Autowired
	private LivrosRepository livrosRepository;

	public List<Livros> getAllLivros() {
		return livrosRepository.findAll();
	}

	public Livros getLivrosById(long id) {
		return livrosRepository.findById(id).orElse(null);
	}

	public Livros saveLivros(Livros livros) {
		return livrosRepository.save(livros);

	}

	// query buscar por titulo service
	public List<Livros> buscarPorTitulo(String titulo) {
		return livrosRepository.buscarPorTitulo(titulo);
	}

	public List<Livros> buscaPorAutor(String autor) {
		return livrosRepository.findByAutor(autor);
	}

}
