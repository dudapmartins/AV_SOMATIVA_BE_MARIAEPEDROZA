package com.MariaPedroza.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MariaPedroza.entities.Autor;
import com.MariaPedroza.entities.Categoria;
import com.MariaPedroza.repository.CategoriaRepository;


@Service
public class CategoriaService {
	
	
	@Autowired
	private CategoriaRepository categoriaRepository;

	public List<Categoria> getAllCategorias() {
		return categoriaRepository.findAll();
	}
	public Categoria getCategoriasById(long id) {
		return categoriaRepository.findById(id).orElse(null);
	}

	public Categoria saveCategoria(Categoria categoria) {
		return categoriaRepository.save(categoria);
	}

}
