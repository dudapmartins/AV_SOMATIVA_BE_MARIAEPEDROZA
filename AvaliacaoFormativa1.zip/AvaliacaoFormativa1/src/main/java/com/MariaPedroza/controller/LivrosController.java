package com.MariaPedroza.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.MariaPedroza.entities.Livros;

import com.MariaPedroza.service.LivrosService;


@RestController
@RequestMapping("/livros")
@CrossOrigin(origins = "http://localhost:8080/livros/")
public class LivrosController {


	private final LivrosService livrosService;

	@Autowired
	public LivrosController(LivrosService livrosService) {
		this.livrosService = livrosService;
	}

	@GetMapping("/{id}")
	public ResponseEntity<Livros> findLivrobyId(@PathVariable Long id) {
		Livros livros = livrosService.getLivrosById(id);
		if (livros != null) {
			return ResponseEntity.ok(livros);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@GetMapping("/")
	public ResponseEntity<List<Livros>> findAllUsuarioscontrol() {
		List<Livros> livro = livrosService.getAllLivros();
		return ResponseEntity.ok(livro);
	}

	

	@PostMapping("/")
	public ResponseEntity<Livros> insertUsuariosControl(@RequestBody Livros livros) {
		Livros novolivros = livrosService.saveLivros(livros);
		return ResponseEntity.status(HttpStatus.CREATED).body(novolivros);
	}

	// query method buscar titulo controler
	@GetMapping("/titulo/{titulo}")
	public List<Livros> buscarPorTitulo(@PathVariable String titulo) {
		return livrosService.buscarPorTitulo(titulo);
	}
	@GetMapping("/autor/{autor}")
	public List<Livros> buscaPorAutor(@PathVariable String autor) {
		return livrosService.buscaPorAutor(autor);}
}
