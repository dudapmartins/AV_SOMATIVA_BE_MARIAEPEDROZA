package com.MariaPedroza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvaliacaoFormativa1Application {

	public static void main(String[] args) {
		SpringApplication.run(AvaliacaoFormativa1Application.class, args);
	}

}
