package com.MariaPedroza.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.MariaPedroza.entities.Livros;

public interface LivrosRepository extends JpaRepository<Livros, Long>{
	@Query(value = "SELECT * FROM Livros l WHERE lower (l.titulo) LIKE %:titulo% ", nativeQuery = true )
	List<Livros>buscarPorTitulo(@Param("titulo") String titulo);
	
	//busca por autor
	@Query("SELECT l From Livros l WHERE l.autor=?1")
	List<Livros>findByAutor(String autor);
}
