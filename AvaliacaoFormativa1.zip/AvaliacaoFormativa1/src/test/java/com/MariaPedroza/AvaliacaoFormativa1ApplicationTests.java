package com.MariaPedroza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvaliacaoFormativa1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
